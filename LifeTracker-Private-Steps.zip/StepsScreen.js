import { useState, useEffect, useRef } from "react";
import { AppState, View, ScrollView, Animated, StyleSheet } from "react-native";
import Svg, { Circle } from "react-native-svg";
import { Ionicons } from "@expo/vector-icons";
import { Pedometer } from "expo-sensors";
import { readHealthConnectToday } from "./healthConnect";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Header from "./Header";
import ThemedText from "./ThemedText";
import { useTheme } from "./ThemeContext";

const STORAGE_KEY = "stepHistory";
const DAILY_GOAL = 6000;
const SIZE = 220;
const STROKE = 18;
const RADIUS = (SIZE - STROKE) / 2;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
const AnimatedCircle = Animated.createAnimatedComponent(Circle);

function dateKey(date) {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

export default function StepsScreen() {
  const { theme } = useTheme();
  const [history, setHistory] = useState({});
  const [loaded, setLoaded] = useState(false);
  const [status, setStatus] = useState("Starting...");
  const lastCount = useRef(0);
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    async function loadHistory() {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        if (saved) setHistory(JSON.parse(saved));
      } finally {
        setLoaded(true);
      }
    }
    loadHistory();
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  }, [history, loaded]);

  async function refreshTodayFromHealthConnect() {
    const total = await readHealthConnectToday();
    if (total == null) return false;
    const today = dateKey(new Date());
    setHistory(old => ({ ...old, [today]: total }));
    setStatus("Background step tracking is on");
    return true;
  }

  useEffect(() => {
    if (!loaded) return;
    let subscription = null;
    let active = true;

    async function startCounting() {
      const healthWorked = await refreshTodayFromHealthConnect();
      if (healthWorked) return;

      const available = await Pedometer.isAvailableAsync();
      if (!available) {
        setStatus("Step sensor is not available on this phone");
        return;
      }

      const permission = await Pedometer.requestPermissionsAsync();
      if (!permission.granted) {
        setStatus("Allow Physical activity permission in phone settings");
        return;
      }

      setStatus("Live tracking is on");
      lastCount.current = 0;
      subscription = Pedometer.watchStepCount(result => {
        if (!active) return;
        const newSteps = result.steps - lastCount.current;
        lastCount.current = result.steps;
        if (newSteps <= 0) return;
        const today = dateKey(new Date());
        setHistory(old => ({ ...old, [today]: (old[today] || 0) + newSteps }));
      });
    }

    startCounting();

    const appState = AppState.addEventListener("change", async state => {
      if (state === "active") await refreshTodayFromHealthConnect();
    });

    return () => {
      active = false;
      if (subscription) subscription.remove();
      appState.remove();
    };
  }, [loaded]);

  const todaySteps = history[dateKey(new Date())] || 0;
  const fraction = Math.min(todaySteps / DAILY_GOAL, 1);

  useEffect(() => {
    Animated.timing(progress, { toValue: fraction, duration: 800, useNativeDriver: false }).start();
  }, [fraction]);

  const strokeDashoffset = progress.interpolate({ inputRange: [0, 1], outputRange: [CIRCUMFERENCE, 0] });
  const distanceKm = (todaySteps * 0.0008).toFixed(2);
  const calories = Math.round(todaySteps * 0.04);

  const lastSevenDays = [];
  for (let i = 6; i >= 0; i--) {
    const day = new Date();
    day.setDate(day.getDate() - i);
    const key = dateKey(day);
    lastSevenDays.push({ key, label: day.toLocaleDateString("en-US", { weekday: "short" }), steps: history[key] || 0, isToday: i === 0 });
  }

  const cardStyle = {
    backgroundColor: theme.card,
    borderColor: theme.cardBorder,
    borderWidth: theme.borderWidth,
    borderRadius: theme.radius,
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}> 
      <Header title="Steps" subtitle={status} />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={[styles.ringCard, cardStyle]}>
          <View style={styles.ringWrapper}>
            <Svg width={SIZE} height={SIZE}>
              <Circle cx={SIZE / 2} cy={SIZE / 2} r={RADIUS} stroke={theme.inputBg} strokeWidth={STROKE} fill="none" />
              <AnimatedCircle cx={SIZE / 2} cy={SIZE / 2} r={RADIUS} stroke={theme.primary} strokeWidth={STROKE} fill="none" strokeLinecap="round" strokeDasharray={CIRCUMFERENCE} strokeDashoffset={strokeDashoffset} rotation="-90" origin={`${SIZE / 2}, ${SIZE / 2}`} />
            </Svg>
            <View style={styles.ringCenter}>
              <Ionicons name="footsteps" size={28} color={theme.primary} />
              <ThemedText style={styles.stepsNumber}>{todaySteps}</ThemedText>
              <ThemedText style={{ color: theme.subText }}>of {DAILY_GOAL} steps</ThemedText>
            </View>
          </View>
        </View>

        <View style={styles.statRow}>
          <View style={[styles.statCard, cardStyle]}><Ionicons name="flame" size={26} color={theme.accent} /><ThemedText style={styles.statValue}>{calories}</ThemedText><ThemedText style={[styles.statLabel, { color: theme.subText }]}>kcal (approx)</ThemedText></View>
          <View style={[styles.statCard, cardStyle]}><Ionicons name="navigate" size={26} color={theme.accent2} /><ThemedText style={styles.statValue}>{distanceKm}</ThemedText><ThemedText style={[styles.statLabel, { color: theme.subText }]}>km (approx)</ThemedText></View>
        </View>

        <View style={[styles.weekCard, cardStyle]}>
          <ThemedText style={styles.weekTitle}>Last 7 days</ThemedText>
          <View style={styles.weekRow}>
            {lastSevenDays.map(day => {
              const barHeight = Math.max(Math.min(day.steps / DAILY_GOAL, 1) * 100, 6);
              return <View key={day.key} style={styles.dayColumn}>
                <ThemedText style={[styles.dayCount, { color: theme.subText }]}>{day.steps}</ThemedText>
                <View style={styles.barTrack}><View style={[styles.bar, { height: barHeight, backgroundColor: day.isToday ? theme.primary : theme.accent2 }]} /></View>
                <ThemedText style={[styles.dayLabel, { color: day.isToday ? theme.primary : theme.subText }, day.isToday && { fontWeight: "bold" }]}>{day.label}</ThemedText>
              </View>;
            })}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16, paddingBottom: 30 },
  ringCard: { padding: 20, alignItems: "center", marginTop: -10 },
  ringWrapper: { width: SIZE, height: SIZE },
  ringCenter: { position: "absolute", width: SIZE, height: SIZE, justifyContent: "center", alignItems: "center" },
  stepsNumber: { fontSize: 40, fontWeight: "bold" },
  statRow: { flexDirection: "row", marginTop: 16 },
  statCard: { flex: 1, padding: 16, marginHorizontal: 6 },
  statValue: { fontSize: 26, fontWeight: "bold", marginTop: 6 },
  statLabel: { fontSize: 12 },
  weekCard: { padding: 16, marginTop: 16 },
  weekTitle: { fontSize: 16, fontWeight: "bold", marginBottom: 12 },
  weekRow: { flexDirection: "row", justifyContent: "space-between" },
  dayColumn: { alignItems: "center", flex: 1 },
  dayCount: { fontSize: 9, marginBottom: 4 },
  barTrack: { height: 100, justifyContent: "flex-end" },
  bar: { width: 22, borderRadius: 11 },
  dayLabel: { marginTop: 6, fontSize: 12 },
});
